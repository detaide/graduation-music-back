module.exports = {
    moduleNameMapper: {
      '^@/(.*)$' : '<rootDir>/src/$1'
    }
  };