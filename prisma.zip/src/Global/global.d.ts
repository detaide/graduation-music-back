declare global{
    interface BigInt {
        toString : () => string;
    }
}

