export function currTime()
{
    return new Date().getTime();
}

export default {
    currTime
}